create table orders (order_id int not null primary key, date date not null,time time not null);
desc order_details;
# Basics
# 1.Retrieve the total number of orders placed.
select count(order_id) as Total_Orders from orders;

# 2.Calculate the total revenue generated from pizza sales.
select round(sum(od.quantity*pz.price)) as Total_revenue from 
order_details od inner join pizzas pz on od.pizza_id = pz.pizza_id;

# 3.Identify the highest-priced pizza.
select pza.name,pz.price  from pizzas pz inner join pizza_types pza on
pza.pizza_type_id= pz.pizza_type_id order by pz.price desc limit 1;

# 4.Identify the most common pizza size ordered.
select  pz.size,count(od.order_details_id) from order_details as od
inner join pizzas as pz on od.pizza_id = pz.pizza_id group by size limit 1;

# 5.List the top 5 most ordered pizza types along with their quantities.
select pza.name,sum(od.quantity) total_quantity from pizza_types pza join pizzas pz
on pz.pizza_type_id = pza.pizza_type_id join order_details od 
on od.pizza_id =pz.pizza_id group by pza.name order by sum(od.quantity) desc limit 5;

#Intermediate:
# 6.Join the necessary tables to find the total quantity of each pizza category ordered.
select pza.category,sum(od.quantity) as Total_Quantity from order_details od join pizzas pz
on pz.pizza_id = od.pizza_id join pizza_types pza on pza.pizza_type_id = pz.pizza_type_id
group by pza.category order by Total_quantity;

# 7.Determine the distribution of orders by hour of the day.
select hour(time) hours, count(order_id) as Total_orders from orders group by hour(time)
order by hour(time);

# 8.Join relevant tables to find the category-wise distribution of pizzas.
select category, count(name) from pizza_types group by category;

# 9. Group the orders by date and calculate the average number of pizzas ordered per day.
select round(avg(quantity)) avg_pizza from
(select o.date,sum(od.quantity) quantity from orders o join order_details od on
od.order_id = o.order_id group by o.date) as data;

# 10. Determine the top 3 most ordered pizza types based on revenue.
select pza.name,round(sum(od.quantity*pz.price)) revenue from order_details od join pizzas pz
on pz.pizza_id=od.pizza_id join pizza_types pza on pza.pizza_type_id= pz.pizza_type_id
group by pza.name order by revenue desc limit 3;

# 11.Calculate the percentage contribution of each pizza type to total revenue.
with total as (select round(sum(od.quantity*pz.price)) revenue from order_details od join pizzas pz
on pz.pizza_id=od.pizza_id join pizza_types pza on pza.pizza_type_id= pz.pizza_type_id)
select pza.category, round(sum(od.quantity*pz.price)/(select * from total)*100,2) percentage from pizzas pz join order_details od
on pz.pizza_id = od.pizza_id join pizza_types pza on pza.pizza_type_id = pz.pizza_type_id
group by  pza.category;

# 12. Analyze the cumulative revenue generated over time.
select date, sum(revenue) over (order by date) as Cum_revenue from  
(select o.date,round(sum(od.quantity*pz.price)) revenue from order_details od join orders o
on o.order_id =od.order_id join pizzas pz on pz.pizza_id = od.pizza_id
group by o.date) Total_revenue;







